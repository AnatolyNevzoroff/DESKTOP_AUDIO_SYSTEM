var group___g_a01_structrda__reg05_8refined =
[
    [ "VOLUME", "group___g_a01.html#a730956af87021c351084317bbc63eea6", null ],
    [ "LNA_ICSEL_BIT", "group___g_a01.html#a160505dce0d227e0f21232f52fef890f", null ],
    [ "LNA_PORT_SEL", "group___g_a01.html#a11b8f14c44524bb37f0a89d4b5559a94", null ],
    [ "SEEKTH", "group___g_a01.html#a991f75a1bf4d56192acecdf31ad3db47", null ],
    [ "RSVD2", "group___g_a01.html#a8d50eb6e30711e4eb7625e651ed1a11d", null ],
    [ "SEEK_MODE", "group___g_a01.html#ac34168e070146678d72546abc1c8b236", null ],
    [ "INT_MODE", "group___g_a01.html#a54e8dc27cd18af681fec547952404531", null ]
];
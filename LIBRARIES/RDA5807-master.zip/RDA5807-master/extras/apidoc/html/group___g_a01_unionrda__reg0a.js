var group___g_a01_unionrda__reg0a =
[
    [ "refined", "group___g_a01.html#ac3a52ed2e4783d2bb7c1e82716c98af3", null ],
    [ "raw", "group___g_a01.html#a4739c58f7e2dcffa54e2368e98716e99", null ]
];
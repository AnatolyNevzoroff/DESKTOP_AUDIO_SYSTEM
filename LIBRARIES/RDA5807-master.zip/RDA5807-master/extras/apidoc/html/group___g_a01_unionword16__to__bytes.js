var group___g_a01_unionword16__to__bytes =
[
    [ "refined", "group___g_a01.html#aac9f5d78f176c0422d073877cd65fe51", null ],
    [ "raw", "group___g_a01.html#abed44166b8c3d82c0c44fb317d3b650a", null ]
];
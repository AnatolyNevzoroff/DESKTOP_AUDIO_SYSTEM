var group___g_a01_unionrda__reg0b =
[
    [ "refined", "group___g_a01.html#a0eeacb17a43648ed4c922fb16253fa5c", null ],
    [ "raw", "group___g_a01.html#a025a972ff39a3584183e12de290d0fb6", null ]
];
var group___g_a01_unionrda__reg0c =
[
    [ "refined", "group___g_a01.html#aa8b7d1851c44335e2380eb7a4468c093", null ],
    [ "RDSA", "group___g_a01.html#aa84daa949defa1d8459599e6a5f7774e", null ]
];
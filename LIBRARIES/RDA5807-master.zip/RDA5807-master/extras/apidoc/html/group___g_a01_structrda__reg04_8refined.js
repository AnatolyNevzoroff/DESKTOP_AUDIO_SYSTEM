var group___g_a01_structrda__reg04_8refined =
[
    [ "GPIO1", "group___g_a01.html#a0ed149a12d2a87f1496cdc90c23bfb1c", null ],
    [ "GPIO2", "group___g_a01.html#ac8715973930ed16be4d52340ef11181b", null ],
    [ "GPIO3", "group___g_a01.html#af2d579fe9d83fc7fe6f55c570c02af38", null ],
    [ "I2S_ENABLE", "group___g_a01.html#aff7333bc2a0234725b53e4e4207e1915", null ],
    [ "RSVD1", "group___g_a01.html#a1742cf1b14a750532e645aab85933d3c", null ],
    [ "AFCD", "group___g_a01.html#afddec52dd7b530641dc1ae72d27a429f", null ],
    [ "SOFTMUTE_EN", "group___g_a01.html#a7e06d843d0840990717eb42b3b7e554c", null ],
    [ "RDS_FIFO_CLR", "group___g_a01.html#a28055088ef40b9bdc9378b3809a21199", null ],
    [ "DE", "group___g_a01.html#a3a52f3c22ed6fcde5bf696a6c02c9e73", null ],
    [ "RDS_FIFO_EN", "group___g_a01.html#a39f20b8df74171b4ee31bab0b0680310", null ],
    [ "RBDS", "group___g_a01.html#a9acb1f82a2515f84bce0747ced06fed8", null ],
    [ "STCIEN", "group___g_a01.html#ab09bf67829bc4d5914945a87be624698", null ],
    [ "RSVD2", "group___g_a01.html#a8d50eb6e30711e4eb7625e651ed1a11d", null ]
];
var searchData=
[
  ['oscillator_5ftype_5fcrystal_290',['OSCILLATOR_TYPE_CRYSTAL',['../_r_d_a5807_8h.html#ad0763fd256db4ec1ecc62f84bbff56e2',1,'RDA5807.h']]],
  ['oscillator_5ftype_5frefclk_291',['OSCILLATOR_TYPE_REFCLK',['../_r_d_a5807_8h.html#ad079e38ccae2f64aa341332e2ccb8b8e',1,'RDA5807.h']]]
];

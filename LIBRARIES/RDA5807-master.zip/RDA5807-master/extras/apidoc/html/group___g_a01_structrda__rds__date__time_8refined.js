var group___g_a01_structrda__rds__date__time_8refined =
[
    [ "offset", "group___g_a01.html#a7a86c157ee9713c34fbd7a1ee40f0c5a", null ],
    [ "offset_sense", "group___g_a01.html#a5ba6e404c489ff4f757e7c77cb9fa310", null ],
    [ "minute1", "group___g_a01.html#a756bdae430708e155654a844c2bcc33b", null ],
    [ "minute2", "group___g_a01.html#a57b42af48e9b3407c002d157d89f50ad", null ],
    [ "hour1", "group___g_a01.html#a0351524e66b386b6638dd47c0d00de65", null ],
    [ "hour2", "group___g_a01.html#a38034b153ffba397eebfcd07b4a50414", null ],
    [ "mjd", "group___g_a01.html#a7f7685b39180278dd0fa69f523c7bd24", null ]
];
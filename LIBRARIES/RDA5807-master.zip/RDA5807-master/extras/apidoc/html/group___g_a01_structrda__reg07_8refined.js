var group___g_a01_structrda__reg07_8refined =
[
    [ "FREQ_MODE", "group___g_a01.html#aad08cffd0c185c95ee8611afce73ec18", null ],
    [ "SOFTBLEND_EN", "group___g_a01.html#a6183fe98d5a6c9859da1f4d1bd75af33", null ],
    [ "SEEK_TH_OLD", "group___g_a01.html#a733877b31393b0f040b3a649004e8e5d", null ],
    [ "RSVD1", "group___g_a01.html#a1742cf1b14a750532e645aab85933d3c", null ],
    [ "MODE_50_60", "group___g_a01.html#a07e1e84799a0bd2c979bff75111e85d5", null ],
    [ "TH_SOFRBLEND", "group___g_a01.html#a76b1c2c14aefb604449d3ff3f0ae80c4", null ],
    [ "RSVD2", "group___g_a01.html#a8d50eb6e30711e4eb7625e651ed1a11d", null ]
];
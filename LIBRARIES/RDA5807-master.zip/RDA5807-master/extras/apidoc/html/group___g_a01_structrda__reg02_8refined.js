var group___g_a01_structrda__reg02_8refined =
[
    [ "ENABLE", "group___g_a01.html#ab332708e4304e13c9b424e7465254954", null ],
    [ "SOFT_RESET", "group___g_a01.html#afea1117fa1ab6be6c3b43d3df783cce0", null ],
    [ "NEW_METHOD", "group___g_a01.html#a60923301c913b155d020368e74200657", null ],
    [ "RDS_EN", "group___g_a01.html#a1ede90c00f1a2c926163d5203ec3b75e", null ],
    [ "CLK_MODE", "group___g_a01.html#a7f2173081ed2422920d15baa1919e01b", null ],
    [ "SKMODE", "group___g_a01.html#a3afc70c9a6693899b152ca51a42f07b7", null ],
    [ "SEEK", "group___g_a01.html#a71fa98cecf9e896e77d11325dbe19dc6", null ],
    [ "SEEKUP", "group___g_a01.html#aed8a1fd68dec9364930b51d020ba07d6", null ],
    [ "RCLK_DIRECT_IN", "group___g_a01.html#ad1ec79cd81992e6bd3131ce076f78679", null ],
    [ "NON_CALIBRATE", "group___g_a01.html#a253053953b1971ea97f782cc746e5e55", null ],
    [ "BASS", "group___g_a01.html#ae1618eb6a84ac61faefe0a87d5649689", null ],
    [ "MONO", "group___g_a01.html#af5f75f1b95652443e4398974b82c3f7c", null ],
    [ "DMUTE", "group___g_a01.html#af7dd74521218c605e3553fdeb618e6eb", null ],
    [ "DHIZ", "group___g_a01.html#adec239f2597576f6182f387472c2272b", null ]
];
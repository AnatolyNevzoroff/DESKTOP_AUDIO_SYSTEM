var group___g_a01_unionrda__reg08 =
[
    [ "refined", "group___g_a01.html#a6b901f2c85429c6822d5e8dc19d1c780", null ],
    [ "raw", "group___g_a01.html#a2d961192507c9b5dcaa83bb2b41c1430", null ]
];